from KTLT_Project.libs.JsonFileFactory import JsonFileFactory
from KTLT_Project.models.Admin import Admin

jff=JsonFileFactory()
filename="../database/admin.json"
admins=jff.read_data(filename,Admin)
print("Danh sach Admin sau khi doc file:")
for admin in admins:
    print(admin)
