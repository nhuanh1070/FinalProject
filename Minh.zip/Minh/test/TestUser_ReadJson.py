from KTLT_Project.libs.JsonFileFactory import JsonFileFactory
from KTLT_Project.models.User import User

jff=JsonFileFactory()
filename="../database/user.json"
users=jff.read_data(filename,User)
print("Danh sách người dùng sau khi loading:")
for user in users:
    print(user)