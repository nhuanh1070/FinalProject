from KTLT_Project.libs.JsonFileFactory import JsonFileFactory
from KTLT_Project.models.Film import Film

jff=JsonFileFactory()
filename="../database/film.json"
films=jff.read_data(filename,Film)
print("Danh sách film sau khi loading:")
for film in films:
    print(film)