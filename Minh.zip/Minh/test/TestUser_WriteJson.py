from KTLT_Project.libs.JsonFileFactory import JsonFileFactory
from KTLT_Project.models.User import User

users=[]
users.append(User("Tèo","teo456","teo456@gmail.com",965805999))
users.append(User("Tý","ty456","ty456@gmail.com",965805998))
users.append(User("Bin","bin456","bin456@gmail.com",965805997))
print ("Danh sách người dùng:")
for user in users:
    print(user)
jff=JsonFileFactory()
filename="../database/user.json"
jff.write_data(users,filename)