class User:
    def __init__(self,Username,Password,Email,Phone):
        self.Username=Username
        self.Password=Password
        self.Email=Email
        self.Phone=Phone
    def __str__(self):
        return f'{self.Username}\t{self.Password}\t{self.Email}\t{self.Phone}'